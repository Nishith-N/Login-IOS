//
//  ViewController.swift
//  login
//
//  Created by Nishith on 27/05/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var emailtxt: UITextField!
    @IBOutlet weak var pwdtext: UITextField!
    @IBOutlet weak var appleimage: UIImageView!
    @IBOutlet weak var twitterimage: UIImageView!
    @IBOutlet weak var googleimage: UIImageView!
    @IBOutlet weak var facebookimage: UIImageView!
    var uname = ""
    var pwd = ""
    @IBAction func loginbtn(_ sender: UIButton) {
        
        self.uname = emailtxt.text!
        self.pwd = pwdtext.text!
        performSegue(withIdentifier: "valuepass", sender: self)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        facebookimage.layer.cornerRadius = 45.0 ;
        facebookimage.clipsToBounds = true
        twitterimage.layer.cornerRadius = 45.0 ;
        twitterimage.clipsToBounds = true
        googleimage.layer.cornerRadius = 45.0 ;
        googleimage.clipsToBounds = true
        appleimage.layer.cornerRadius = 45.0 ;
        appleimage.clipsToBounds = true
        emailtxt.layer.borderColor = UIColor.lightGray.cgColor
        emailtxt.layer.borderWidth = 1.0;
    
        pwdtext.layer.borderColor = UIColor.lightGray.cgColor
        pwdtext.layer.borderWidth = 1.0;
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc=segue.destination as! SecondViewController
        vc.Finaluname=self.uname
        vc.Finalpwd=self.pwd
    }

}
